function sum(a, b) {
    return a +b;
}

function nativeAlert(message) {
    alert(message);
}