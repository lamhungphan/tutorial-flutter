// In order to *not* need this ignore, consider extracting the "web" version
// of your plugin as a separate package, instead of inlining it in the same
// package as the core of your plugin.
// ignore: avoid_web_libraries_in_flutter

import 'package:flutter_web_plugins/flutter_web_plugins.dart';
import 'package:web/web.dart' as web;
import 'dart:js_interop' as js;

import 'plugin_demo_platform_interface.dart';

@js.JS('nativeAlert')
external void nativeAlert(String message);

@js.JS('sum') // Ánh xạ tới hàm 'sum' trong scope toàn cục của JavaScript
external int sumJs(int a, int b);

/// A web implementation of the PluginDemoPlatform of the PluginDemo plugin.
class PluginDemoWeb extends PluginDemoPlatform {
  /// Constructs a PluginDemoWeb
  PluginDemoWeb();

  static void registerWith(Registrar registrar) {
    PluginDemoPlatform.instance = PluginDemoWeb();
  }

  /// Returns a [String] containing the version of the platform.
  @override
  Future<String?> getPlatformVersion() async {
    final version = web.window.navigator.userAgent;
    return version;
  }

  @override
  Future<int> sum(int a, int b) {
    int r = sumJs(a,b);
    return Future(() => r);
  }

  @override
  Future<void> getNativeAlert() {
    nativeAlert("hello from js");
    return Future(() => null);
  }
}
