import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CounterCubit extends Cubit<int> {
  SharedPreferences _prefs;

  CounterCubit(this._prefs) : super(0);

  void increment() => emit(state + 1);

  void decrement() => emit(state - 1);

  Future<void> save() async {
    await _prefs.setInt('counter', state);
  }

  load() {
    var counter = _prefs.getInt('counter') ?? 0;
    emit(counter);
  }
}

Future<void> main() async {
  var sharedPreferences = await SharedPreferences.getInstance();
  runApp(
    BlocProvider(
      create: (context) => CounterCubit(sharedPreferences),
      child: MaterialApp(
        home: SafeArea(
          child: Page(),
        ),
      ),
    ),
  );
}

class Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var cubit = context.read<CounterCubit>();
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            BlocBuilder<CounterCubit, int>(
              builder: (context, state) {
                return Text(
                  "$state",
                  style: TextStyle(fontSize: 30),
                );
              },
            ),
            SizedBox(height: 32),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: () => cubit.increment(), icon: Icon(Icons.add)),
                IconButton(onPressed: () => cubit.decrement(), icon: Icon(Icons.remove)),
                IconButton(onPressed: () => cubit.save(), icon: Icon(Icons.save)),
                IconButton(onPressed: () => cubit.load(), icon: Icon(Icons.settings_backup_restore)),
              ],
            )
          ],
        ),
      ),
    );
  }
}
