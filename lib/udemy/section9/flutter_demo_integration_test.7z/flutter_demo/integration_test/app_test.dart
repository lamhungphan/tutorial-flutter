import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_demo/main.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_demo/main.dart' as demo;

class MockPref extends Mock implements SharedPreferences {}

class MockNavigatorObserver extends Mock implements NavigatorObserver{}

class FakeRoute extends Fake implements Route {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  group('Test counter', () {
    late SharedPreferences pref;
    late CounterCubit counterCubit;
    setUp(() {
      pref = MockPref();
      counterCubit = CounterCubit(pref);
      registerFallbackValue(FakeRoute());
      when(() => pref.setInt(any(), any())).thenAnswer((_) async => Future(() => true));
    });
    testWidgets("Test increment", (widgetTester) async {
      //create ui
      await widgetTester.pumpWidget(BlocProvider(
        create: (context) => CounterCubit(pref),
        child: MaterialApp(home: demo.Page()),
      ));
      var counter = find.text("0");
      expect(counter, findsOneWidget);

      //tap
      var increment = find.widgetWithIcon(IconButton, Icons.add);
      await widgetTester.tap(increment);
      var counter2 = find.text("1");
      await widgetTester.pumpAndSettle(); //refresh ui
      expect(counter2, findsOneWidget);
    });

    testWidgets("test navigation", (widgetTester) async{
      var mockObserver = MockNavigatorObserver();
      await widgetTester.pumpWidget(BlocProvider(
        create: (context) => CounterCubit(pref),
        child: MaterialApp(home: demo.Page(),
          navigatorObservers: [mockObserver],),
      ));
      var nextButton = find.byKey(Key("Navigation"));
      await widgetTester.tap(nextButton);
      verify(() => mockObserver.didPush(any(), any())).called(2);
    });
  });
}
